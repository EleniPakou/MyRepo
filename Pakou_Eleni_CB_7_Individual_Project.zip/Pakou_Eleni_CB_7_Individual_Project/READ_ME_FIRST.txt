﻿
-Τα username/password είναι:

	student1/student1
	...έως
	student10/student10

	trainer1/trainer1
	...έως
	trainer6/trainer6

	headmaster/headmaster


-Η στήλη Password στους πίνακες students_login, trainers_login, headmastermaster_login κανονικά δεν θα έπρεπε
	να υπάρχει (για περισσότερη ασφάλεια) μιας κι έχουμε αποθηκεύσει τα hashed passwords. Την αφήνω όμως
	προς το παρόν για διευκόλυνση.