CREATE DATABASE  IF NOT EXISTS `private_school` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `private_school`;
-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: private_school
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `trainers_login`
--

DROP TABLE IF EXISTS `trainers_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `trainers_login` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `tID` int(11) NOT NULL,
  `UserName` varchar(45) DEFAULT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `Hash` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `trainersIDc_idx` (`tID`),
  CONSTRAINT `trainersIDc` FOREIGN KEY (`tID`) REFERENCES `trainers` (`trainersID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trainers_login`
--

LOCK TABLES `trainers_login` WRITE;
/*!40000 ALTER TABLE `trainers_login` DISABLE KEYS */;
INSERT INTO `trainers_login` VALUES (1,1,'trainer1','trainer1','1000:0fa09ef0990d7ad6b6ab6d3cced48fad:e66ef16906c0ec1864c311a535c6b8d4e922c8e10dfc86a86b8088c150db3c2b068639c3e2e513fb95880d8b10fbd7a937a8e5bd9ad293840edc55b0fabfb889'),(2,2,'trainer2','trainer2','1000:0fa09ef0990d7ad6b6ab6d3cced48fad:923c5c376eaf00aee78b0405e7e92f03a954b73cf1ce29a21fd3ca3f5a7988d28d6386f29576b03029d2a8abbdb83ae0ec5a12e34a5ad46ae3e165a6893849a9'),(3,3,'trainer3','trainer3','1000:0fa09ef0990d7ad6b6ab6d3cced48fad:7e650e38dfdeb267f0c653f22d480032e66020187684e0cb3768d8cdbb9c348fdd1fcc874043441563efcb6aa4d65cba0556c82aae591e7cccbbf90bbc82c95c'),(4,4,'trainer4','trainer4','1000:0fa09ef0990d7ad6b6ab6d3cced48fad:e050196dcc3a3035ac494097d623337493f829e69166954f34aaaa66dd4a0eaedac4db6fc8b05f2f8e69a3375d3648b4853d313ae907060d20d29ea6d39c084c'),(5,5,'trainer5','trainer5','1000:0fa09ef0990d7ad6b6ab6d3cced48fad:2ca59721fe40474e0cff9d44ae5566c3009d564915ddd67480f50816257f837e95c4b31f791c281bb9d498abbc6aaae0c22b98180f6f5e6a59010dea9672ffc7'),(6,6,'trainer6','trainer6','1000:0fa09ef0990d7ad6b6ab6d3cced48fad:154e246552b3f08c94061fe2972130edec41e475db51ccc505c3a5203295caf13ff424c2e4d59e584ba97e45a56afe458b40f3348207686fcfc069132b337268');
/*!40000 ALTER TABLE `trainers_login` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-31  8:10:16
