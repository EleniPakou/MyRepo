CREATE DATABASE  IF NOT EXISTS `private_school` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `private_school`;
-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: private_school
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assignments_per_course_per_student`
--

DROP TABLE IF EXISTS `assignments_per_course_per_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `assignments_per_course_per_student` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `sID` int(11) DEFAULT NULL,
  `aID` int(11) DEFAULT NULL,
  `SubmittedOn` date DEFAULT NULL,
  `OralMarkGiven` int(11) DEFAULT NULL,
  `TotalMarkGiven` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `studentsIDc_idx` (`sID`),
  KEY `assignmentsIDc_idx` (`aID`),
  CONSTRAINT `assignmentsIDc` FOREIGN KEY (`aID`) REFERENCES `assignments` (`assignmentsID`),
  CONSTRAINT `studentsIDc` FOREIGN KEY (`sID`) REFERENCES `students` (`studentsID`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignments_per_course_per_student`
--

LOCK TABLES `assignments_per_course_per_student` WRITE;
/*!40000 ALTER TABLE `assignments_per_course_per_student` DISABLE KEYS */;
INSERT INTO `assignments_per_course_per_student` VALUES (1,1,1,NULL,NULL,NULL),(2,1,2,NULL,NULL,NULL),(3,1,5,NULL,NULL,NULL),(4,1,6,NULL,NULL,NULL),(5,2,1,NULL,NULL,NULL),(6,2,2,NULL,NULL,NULL),(7,2,7,NULL,NULL,NULL),(8,2,8,NULL,NULL,NULL),(9,3,1,NULL,NULL,NULL),(10,3,2,NULL,NULL,NULL),(11,3,5,NULL,NULL,NULL),(12,3,6,NULL,NULL,NULL),(13,4,1,NULL,NULL,NULL),(14,4,2,NULL,NULL,NULL),(15,5,3,NULL,NULL,NULL),(16,5,4,NULL,NULL,NULL),(17,6,3,NULL,NULL,NULL),(18,6,4,NULL,NULL,NULL),(19,7,3,NULL,NULL,NULL),(20,7,4,NULL,NULL,NULL),(21,8,5,NULL,NULL,NULL),(22,8,6,NULL,NULL,NULL),(23,9,7,NULL,NULL,NULL),(24,9,8,NULL,NULL,NULL),(25,10,7,NULL,NULL,NULL),(26,10,8,NULL,NULL,NULL);
/*!40000 ALTER TABLE `assignments_per_course_per_student` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-31  8:10:17
