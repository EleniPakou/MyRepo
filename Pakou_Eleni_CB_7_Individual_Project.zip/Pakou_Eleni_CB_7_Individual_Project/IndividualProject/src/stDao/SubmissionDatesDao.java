package stDao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lena
 */
public class SubmissionDatesDao {

    private final String URL = "jdbc:mysql://localhost:3306/private_school?serverTimezone=UTC";
    private final String USERNAME = "root";
    private final String PASS = "001908xxxx";
    private Connection conn;

    private Connection getConnection() {
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
//            System.out.println("Connection successfully established.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }

    private void closeConnection() {
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(SubmissionDatesDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void getSubmissionDates(int studentsID) {
        String query = "select c.Title, c.Stream, c.Type, a.Title, a.Submission "
                + "from assignments_per_course_per_student apcps, students s, courses c, assignments a "
                + "where s.studentsID = apcps.sID and c.coursesID = a.cID and a.assignmentsID = apcps.aID "
                + "and studentsID = ? order by apcps.ID";
        Connection con = getConnection();
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            pst = con.prepareStatement(query);
            pst.setInt(1, studentsID);
            rs = pst.executeQuery();
            while (rs.next()) {
                String title = rs.getString("c.Title");
                String stream = rs.getString("c.Stream");
                String type = rs.getString("c.Type");
                String atitle = rs.getString("a.Title");
                String submission = rs.getString("a.Submission");
                
                System.out.println(title+" "+stream+" "+type+" "+atitle+" "+submission);
            }

        } catch (SQLException x) {
            Logger.getLogger(SubmissionDatesDao.class.getName()).log(Level.SEVERE, null, x);
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException x) {
                Logger.getLogger(SubmissionDatesDao.class.getName()).log(Level.SEVERE, null, x);
            }
        }
    }

}
