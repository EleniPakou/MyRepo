package stDao;

import menus.StMenu;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lena
 */
public class EnrollDao {
    private final String URL = "jdbc:mysql://localhost:3306/private_school?serverTimezone=UTC";
    private final String USERNAME = "root";
    private final String PASS = "001908xxxx";
    private Connection conn;

    private Connection getConnection() {
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
//            System.out.println("Connection successfully established.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }

    private void closeConnection() {
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(EnrollDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void viewTrainersPerCourse(){
        String query = "select tpc.ID, c.Title, c.Stream, c.Type, t.FirstName, t.LastName "
                + "from trainers_per_course tpc "
                + "inner join courses c on tpc.cID = c.coursesID "
                + "inner join trainers t on tpc.tID = t.trainersID";
        
        Connection con = getConnection();
        PreparedStatement pst = null;
        ResultSet rs = null;
        try {
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("tpc.ID");
                String title = rs.getString("c.Title");
                String stream = rs.getString("c.Stream");
                String type = rs.getString("c.Type");
                String firstName = rs.getString("t.FirstName");
                String lastName = rs.getString("t.LastName");
                
                System.out.println("ID="+id+" | "+title+" "+stream+" "+type+" "+firstName+" "+lastName);
            }

        } catch (SQLException x) {
            Logger.getLogger(EnrollDao.class.getName()).log(Level.SEVERE, null, x);
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException x) {
                Logger.getLogger(EnrollDao.class.getName()).log(Level.SEVERE, null, x);
            }
        }
    }    
    
    public void insertIntoStudentsPerCourse(int ID, int sID) throws NoSuchAlgorithmException, InvalidKeySpecException{
        String query = "insert into students_per_course (cID, sID) values ((select cID from trainers_per_course where ID = ?), ?)";
        StMenu stMenu = new StMenu();

       
        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);

            pst.setInt(1, ID);
            pst.setInt(2, sID);
            
            int number = pst.executeUpdate();
            if(number>0){
                System.out.println("\nSuccessfull Enrollment!!!");
                stMenu.getStMenu(sID);
            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(EnrollDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
