package stDao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;
import entitiesPerAndLogin.AssignmentsPerCoursePerStudent;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import menus.StMenu;

/**
 *
 * @author Lena
 */
public class SubmitAssignmentDao {
    private final String URL = "jdbc:mysql://localhost:3306/private_school?serverTimezone=UTC";
    private final String USERNAME = "root";
    private final String PASS = "001908xxxx";
    private Connection conn;

    private Connection getConnection() {
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
//            System.out.println("Connection successfully established.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }

    private void closeConnection() {
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(SubmitAssignmentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void getAssignPCPS(int studentsID) {
        String query = "select apcps.ID, c.Title, c.Stream, c.Type, a.Title, apcps.SubmittedOn "
                + "from assignments_per_course_per_student apcps, students s, courses c, assignments a "
                + "where s.studentsID = apcps.sID and c.coursesID = a.cID and a.assignmentsID = apcps.aID "
                + "and studentsID = ? order by apcps.ID";
        Connection con = getConnection();
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            pst = con.prepareStatement(query);
            pst.setInt(1, studentsID);
            rs = pst.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("apcps.ID");
                String title = rs.getString("c.Title");
                String stream = rs.getString("c.Stream");
                String type = rs.getString("c.Type");
                String atitle = rs.getString("a.Title");
                String submittedOn = rs.getString("apcps.SubmittedOn");
                
                if (submittedOn == null){
                    System.out.println("ID="+id+" | "+title+" "+stream+" "+type+" "+atitle+" NOT-SUBMITTED");
                }
                else{
                    System.out.println("ID="+id+" | "+title+" "+stream+" "+type+" "+atitle);
                }                
            }

        } catch (SQLException x) {
            Logger.getLogger(SubmitAssignmentDao.class.getName()).log(Level.SEVERE, null, x);
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException x) {
                Logger.getLogger(SubmitAssignmentDao.class.getName()).log(Level.SEVERE, null, x);
            }
        }

    }
    public void submitAssignment(int ID, int sID) throws NoSuchAlgorithmException, InvalidKeySpecException{
        String query = "update assignments_per_course_per_student set submittedON = ? where ID = ?";
        StMenu stMenu = new StMenu();
        
        AssignmentsPerCoursePerStudent apcps = new AssignmentsPerCoursePerStudent();
        LocalDate today = LocalDate.now(); 
        apcps.setSubmittedOn(today);
        
        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);
            pst.setDate(1, Date.valueOf(today));
            pst.setInt(2, ID);
            int number = pst.executeUpdate();
            if(number>0){
                System.out.println("\nYou successfully submitted your assignment on " + LocalDate.now());
                stMenu.getStMenu(sID);
            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(SubmitAssignmentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
