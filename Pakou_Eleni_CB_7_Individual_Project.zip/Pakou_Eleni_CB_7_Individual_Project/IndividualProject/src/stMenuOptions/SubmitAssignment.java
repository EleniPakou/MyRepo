package stMenuOptions;

import menus.StMenu;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import stDao.SubmitAssignmentDao;
import java.util.Scanner;

/**
 *
 * @author Lena
 */
public class SubmitAssignment {
    
    public void submitAssignment(int studentsID) throws NoSuchAlgorithmException, InvalidKeySpecException{
        int x;
        StMenu stMenu = new StMenu();
        
        
        SubmitAssignmentDao saDao = new SubmitAssignmentDao();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of your assignments\n");
        saDao.getAssignPCPS(studentsID);
        System.out.println("\nPlease type the ID of the assignment you wish to submit\n"
                + "Or type 0 to go back to students-menu");
        x = input.nextInt();
        if (x==0){
          stMenu.getStMenu(studentsID);
        }
        else saDao.submitAssignment(x, studentsID);
        
    }
    
}
