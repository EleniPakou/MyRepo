package stMenuOptions;

import menus.StMenu;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import stDao.SubmissionDatesDao;
import java.util.Scanner;

/**
 *
 * @author Lena
 */
public class SubmissionDates {

    public void submissionDates(int studentsID) throws NoSuchAlgorithmException, InvalidKeySpecException {
        int x;
        StMenu stMenu = new StMenu();

        SubmissionDatesDao sdDao = new SubmissionDatesDao();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of the dates of submission of all your assignments.\n");
        sdDao.getSubmissionDates(studentsID);

        do {
            System.out.println("\nPlease type 0 to go back to students-menu");
            x = input.nextInt();
            if (x == 0) {
                stMenu.getStMenu(studentsID);
            }
        } while (x != 0);

    }

}
