package stMenuOptions;

import menus.StMenu;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import stDao.EnrollDao;
import java.util.Scanner;

/**
 *
 * @author Lena
 */
public class Enroll {
    
    public void enroll(int studentsID) throws NoSuchAlgorithmException, InvalidKeySpecException{
        int x;
        StMenu stMenu = new StMenu();
        
        
        EnrollDao eDao = new EnrollDao();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of all trainers per course.\n");
        eDao.viewTrainersPerCourse();
        System.out.println("\nPlease type the ID of the course you wish to enroll to\n"
                + "Or type 0 to go back to students-menu");
        x = input.nextInt();
        if (x==0){
          stMenu.getStMenu(studentsID);
        }
        else eDao.insertIntoStudentsPerCourse(x, studentsID);
        
    }
    
}
