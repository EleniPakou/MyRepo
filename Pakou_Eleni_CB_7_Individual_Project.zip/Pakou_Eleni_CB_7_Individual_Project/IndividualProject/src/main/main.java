package main;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import other.Welcome;

/**
 *
 * @author Lena
 */
public class main {

    public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeySpecException {        
        Welcome welcome = new Welcome();
        welcome.welcome(); 
    }
        
}
