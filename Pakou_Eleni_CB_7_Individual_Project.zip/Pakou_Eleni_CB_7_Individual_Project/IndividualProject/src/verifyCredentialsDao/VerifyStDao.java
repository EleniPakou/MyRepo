package verifyCredentialsDao;

import other.LoginAs;
import menus.StMenu;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lena
 */
public class VerifyStDao {

    private final String URL = "jdbc:mysql://localhost:3306/private_school?serverTimezone=UTC";
    private final String USERNAME = "root";
    private final String PASS = "001908xxxx";
    private Connection conn;

    private Connection getConnection() {
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
//            System.out.println("Connection successfully established.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }

    private void closeConnection() {
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(VerifyStDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void getCredentialsSt(String userName, String hashInput) throws NoSuchAlgorithmException, InvalidKeySpecException {
        String query = "select s.studentsID, s.FirstName, sl.UserName, sl.Hash from students_login sl "
                + "inner join students s on sl.sID=s.studentsID";
        LoginAs loginAs = new LoginAs();
        StMenu stMenu = new StMenu();
        Connection con = getConnection();
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while (rs.next()) {
                int studentsID = rs.getInt("s.studentsID");
                String firstname = rs.getString("s.FirstName");
                String username = rs.getString("sl.UserName");
                String hash = rs.getString("sl.Hash");

                if ((userName.equals(username)) && (hashInput.equals(hash))) {
                    System.out.println("\nWelcome, " + firstname);
                    stMenu.getStMenu(studentsID);
                    break;
                } else {
                    if (rs.isLast()) {
                        System.out.println("\nWrong credentials!!! Please try again");
                        loginAs.loginAs();
                    }
                }
            }

        } catch (SQLException x) {
            Logger.getLogger(VerifyStDao.class.getName()).log(Level.SEVERE, null, x);
            x.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException x) {
                Logger.getLogger(VerifyStDao.class.getName()).log(Level.SEVERE, null, x);
                x.printStackTrace();
            }
        }
    }

}
