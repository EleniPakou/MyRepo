package verifyCredentialsDao;

import other.LoginAs;
import menus.TrMenu;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lena
 */
public class VerifyTrDao {

    private final String URL = "jdbc:mysql://localhost:3306/private_school?serverTimezone=UTC";
    private final String USERNAME = "root";
    private final String PASS = "001908xxxx";
    private Connection conn;

    private Connection getConnection() {
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
//            System.out.println("Connection successfully established.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }

    private void closeConnection() {
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(VerifyTrDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void getCredentialsTr(String userName, String hashInput) throws NoSuchAlgorithmException, InvalidKeySpecException {
        String query = "select t.trainersID, t.FirstName, tl.UserName, tl.Hash from trainers_login tl "
                + "inner join trainers t on tl.tID=t.trainersID";
        LoginAs loginAs = new LoginAs();
        TrMenu trMenu = new TrMenu();
        Connection con = getConnection();
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while (rs.next()) {
                int trainersID = rs.getInt("t.trainersID");
                String firstname = rs.getString("t.FirstName");
                String username = rs.getString("tl.UserName");
                String hash = rs.getString("tl.Hash");

                if ((userName.equals(username)) && (hashInput.equals(hash))) {
                    System.out.println("\nWelcome, " + firstname);
                    trMenu.getTrMenu(trainersID);
                    break;
                } else {
                    if (rs.isLast()) {
                        System.out.println("\nWrong credentials!!! Please try again");
                        loginAs.loginAs();
                    }

                }
            }

        } catch (SQLException x) {
            Logger.getLogger(VerifyTrDao.class.getName()).log(Level.SEVERE, null, x);
            x.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException x) {
                Logger.getLogger(VerifyTrDao.class.getName()).log(Level.SEVERE, null, x);
                x.printStackTrace();
            }
        }
    }
}
