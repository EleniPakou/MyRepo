package hmMenuOptions;

import other.BackToHmMenu;
import hmDao.ViewDao;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

/**
 *
 * @author Lena
 */
public class View {
//    ViewDao vDao = new ViewDao();
    public void viewCourses() throws NoSuchAlgorithmException, InvalidKeySpecException {
        ViewDao vDao = new ViewDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        System.out.println("\nBelow is a list of all courses\n");
        vDao.getListOfCourses();
        backToHmMenu.backToHmMenu();
    }
    
    public void viewAssignments() throws NoSuchAlgorithmException, InvalidKeySpecException {
        ViewDao vDao = new ViewDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        System.out.println("\nBelow is a list of all assignments\n");
        vDao.getListOfAssignments();
        backToHmMenu.backToHmMenu();
    }
    
    public void viewStudents() throws NoSuchAlgorithmException, InvalidKeySpecException {
        ViewDao vDao = new ViewDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        System.out.println("\nBelow is a list of all students\n");
        vDao.getListOfStudents();
        backToHmMenu.backToHmMenu();
    }
    
    public void viewTrainers() throws NoSuchAlgorithmException, InvalidKeySpecException {
        ViewDao vDao = new ViewDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        System.out.println("\nBelow is a list of all trainers\n");
        vDao.getListOfTrainers();
        backToHmMenu.backToHmMenu();
    }
    
    public void viewApc() throws NoSuchAlgorithmException, InvalidKeySpecException {
        ViewDao vDao = new ViewDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        System.out.println("\nBelow is a list of all assignments per course\n");
        vDao.getApc();
        backToHmMenu.backToHmMenu();
    }
    
    public void viewSpc() throws NoSuchAlgorithmException, InvalidKeySpecException {
        ViewDao vDao = new ViewDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        System.out.println("\nBelow is a list of all students per course\n");
        vDao.getSpc();
        backToHmMenu.backToHmMenu();
    }
    
    public void viewTpc() throws NoSuchAlgorithmException, InvalidKeySpecException {
        ViewDao vDao = new ViewDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        System.out.println("\nBelow is a list of all trainers per course\n");
        vDao.getTpc();
        backToHmMenu.backToHmMenu();
    }
}
