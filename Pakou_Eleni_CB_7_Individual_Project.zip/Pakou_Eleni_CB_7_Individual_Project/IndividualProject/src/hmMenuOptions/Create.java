package hmMenuOptions;

import other.BackToHmMenu;
import hmDao.CreateDao;
import hmDao.ViewDao;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;

/**
 *
 * @author Lena
 */
public class Create {

    public void createCourse() throws NoSuchAlgorithmException, InvalidKeySpecException {
        CreateDao cDao = new CreateDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        System.out.println("---Adding a course---");
        cDao.insertCourse();
        backToHmMenu.backToHmMenu();
    }

    public void createAssignment() throws NoSuchAlgorithmException, InvalidKeySpecException {
        CreateDao cDao = new CreateDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        System.out.println("---Adding an assignment---");
        cDao.insertAssignment();
        backToHmMenu.backToHmMenu();
    }

    public void createStudent() throws NoSuchAlgorithmException, InvalidKeySpecException {
        CreateDao cDao = new CreateDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        System.out.println("---Adding a student---");
        cDao.insertStudent();
        backToHmMenu.backToHmMenu();
    }

    public void createTrainer() throws NoSuchAlgorithmException, InvalidKeySpecException {
        CreateDao cDao = new CreateDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        System.out.println("---Adding a trainer---");
        cDao.insertTrainer();
        backToHmMenu.backToHmMenu();
    }

    public void createApc() throws NoSuchAlgorithmException, InvalidKeySpecException {
        int x;
        CreateDao cDao = new CreateDao();
        ViewDao vDao = new ViewDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of all courses.\n");
        vDao.getListOfCourses();
        System.out.println("\nPlease type the ID of the course you wish to add an assignment to:\n");
        x = input.nextInt();
        System.out.println("---Adding an assignment---");
        cDao.insertApc(x);
        backToHmMenu.backToHmMenu();
    }

    public void createSpc() throws NoSuchAlgorithmException, InvalidKeySpecException {
        int x, y;
        CreateDao cDao = new CreateDao();
        ViewDao vDao = new ViewDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        Scanner input = new Scanner(System.in);
        System.out.println("\nChoose a student from the list (type the right number)\n");
        vDao.getListOfStudents();
        x = input.nextInt();
        System.out.println("\nEnroll the student to one of the following courses (type the right number)\n");
        vDao.getListOfCourses();
        y = input.nextInt();
        cDao.insertSpc(y, x);
        backToHmMenu.backToHmMenu();
    }
    
    public void createTpc() throws NoSuchAlgorithmException, InvalidKeySpecException {
        int x, y;
        CreateDao cDao = new CreateDao();
        ViewDao vDao = new ViewDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        Scanner input = new Scanner(System.in);
        System.out.println("\nChoose a trainer from the list (type the right number)\n");
        vDao.getListOfTrainers();
        x = input.nextInt();
        System.out.println("\nEnroll the trainer to one of the following courses (type the right number)\n");
        vDao.getListOfCourses();
        y = input.nextInt();
        cDao.insertTpc(y, x);
        backToHmMenu.backToHmMenu();
    }
}
