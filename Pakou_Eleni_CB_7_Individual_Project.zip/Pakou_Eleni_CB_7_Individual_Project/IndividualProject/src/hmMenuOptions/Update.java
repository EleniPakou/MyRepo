package hmMenuOptions;

import other.BackToHmMenu;
import hmDao.UpdateDao;
import hmDao.ViewDao;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;

/**
 *
 * @author Lena
 */
public class Update {
    
    public void updateCourse() throws NoSuchAlgorithmException, InvalidKeySpecException{
        ViewDao vDao = new ViewDao();
        UpdateDao uDao = new UpdateDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        System.out.println("\nBelow is a list of all courses.\n");
        vDao.getListOfCourses();
        uDao.updateCourseById();
        backToHmMenu.backToHmMenu();
    }
    
    public void updateAssignment() throws NoSuchAlgorithmException, InvalidKeySpecException{
        ViewDao vDao = new ViewDao();
        UpdateDao uDao = new UpdateDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        System.out.println("\nBelow is a list of all assignments.\n");
        vDao.getListOfAssignments();
        uDao.updateAssignmentById();
        backToHmMenu.backToHmMenu();
    }
    
    public void updateStudent() throws NoSuchAlgorithmException, InvalidKeySpecException{
        ViewDao vDao = new ViewDao();
        UpdateDao uDao = new UpdateDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        System.out.println("\nBelow is a list of all students.\n");
        vDao.getListOfStudents();
        uDao.updateStudentById();
        backToHmMenu.backToHmMenu();
    }
    
    public void updateTrainer() throws NoSuchAlgorithmException, InvalidKeySpecException{
        ViewDao vDao = new ViewDao();
        UpdateDao uDao = new UpdateDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        System.out.println("\nBelow is a list of all trainers.\n");
        vDao.getListOfTrainers();
        uDao.updateTrainerById();
        backToHmMenu.backToHmMenu();
    }
    
    public void updateApc() throws NoSuchAlgorithmException, InvalidKeySpecException{
        int x,y;
        ViewDao vDao = new ViewDao();
        UpdateDao uDao = new UpdateDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of all assignments per course\n");
        vDao.getApc();
        System.out.println("\nPlease type the ID of the assignment you wish to update:");
        x = input.nextInt();
        System.out.println("\nBelow is a list of all courses\n");
        vDao.getListOfCourses();
        System.out.println("\nPlease add your selected assignment to one of the courses above (type the ID):");
        y = input.nextInt();
        uDao.updateApcById(x, y);
        backToHmMenu.backToHmMenu();
    }
    
    public void updateSpc() throws NoSuchAlgorithmException, InvalidKeySpecException{
        int x,y;
        ViewDao vDao = new ViewDao();
        UpdateDao uDao = new UpdateDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of all students per course\n");
        vDao.getSpc();
        System.out.println("\nPlease type the ID of the course of the student you wish to update:");
        x = input.nextInt();
        System.out.println("\nBelow is a list of all students\n");
        vDao.getListOfStudents();
        System.out.println("\nPlease enroll a student to your selected course (type the ID):");
        y = input.nextInt();
        uDao.updateSpc(x, y);
        backToHmMenu.backToHmMenu();
    }
    
    public void updateTpc() throws NoSuchAlgorithmException, InvalidKeySpecException{
        int x,y;
        ViewDao vDao = new ViewDao();
        UpdateDao uDao = new UpdateDao();
        BackToHmMenu backToHmMenu = new BackToHmMenu();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of all trainers per course\n");
        vDao.getTpc();
        System.out.println("\nPlease type the ID of the course of the trainer you wish to update:");
        x = input.nextInt();
        System.out.println("\nBelow is a list of all trainers\n");
        vDao.getListOfTrainers();
        System.out.println("\nPlease enroll a trainer to your selected course (type the ID):");
        y = input.nextInt();
        uDao.updateSpc(x, y);
        backToHmMenu.backToHmMenu();
    }
}
