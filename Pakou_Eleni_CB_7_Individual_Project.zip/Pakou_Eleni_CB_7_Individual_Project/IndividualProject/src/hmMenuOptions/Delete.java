package hmMenuOptions;

import menus.HmMenu;
import hmDao.DeleteDao;
import hmDao.ViewDao;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;

/**
 *
 * @author Lena
 */
public class Delete {
    
    public void deleteCourse() throws NoSuchAlgorithmException, InvalidKeySpecException{
        int x;
        HmMenu hmMenu = new HmMenu();
        ViewDao vDao = new ViewDao();
        DeleteDao dDao = new DeleteDao();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of all courses.\n");
        vDao.getListOfCourses();
        System.out.println("\nPlease type the ID of the course you wish to delete\n"
                + "Or type 0 to go back to headmaster-menu");
        x = input.nextInt();
        if (x==0){
          hmMenu.hmMenu();
        }
        else dDao.deleteCourseById(x);
        hmMenu.hmMenu();
    }
    
    public void deleteAssignment() throws NoSuchAlgorithmException, InvalidKeySpecException{
        int x;
        HmMenu hmMenu = new HmMenu();
        ViewDao vDao = new ViewDao();
        DeleteDao dDao = new DeleteDao();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of all assignments.\n");
        vDao.getListOfAssignments();
        System.out.println("\nPlease type the ID of the assignment you wish to delete\n"
                + "Or type 0 to go back to headmaster-menu");
        x = input.nextInt();
        if (x==0){
          hmMenu.hmMenu();
        }
        else dDao.deleteAssignmentById(x);
        hmMenu.hmMenu();
    }
    
    public void deleteStudent() throws NoSuchAlgorithmException, InvalidKeySpecException{
        int x;
        HmMenu hmMenu = new HmMenu();
        ViewDao vDao = new ViewDao();
        DeleteDao dDao = new DeleteDao();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of all students.\n");
        vDao.getListOfStudents();
        System.out.println("\nPlease type the ID of the student you wish to delete\n"
                + "Or type 0 to go back to headmaster-menu");
        x = input.nextInt();
        if (x==0){
          hmMenu.hmMenu();
        }
        else dDao.deleteStudentById(x);
        hmMenu.hmMenu();
    }
    
    public void deleteTrainer() throws NoSuchAlgorithmException, InvalidKeySpecException{
        int x;
        HmMenu hmMenu = new HmMenu();
        ViewDao vDao = new ViewDao();
        DeleteDao dDao = new DeleteDao();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of all trainers.\n");
        vDao.getListOfTrainers();
        System.out.println("\nPlease type the ID of the trainer you wish to delete\n"
                + "Or type 0 to go back to headmaster-menu");
        x = input.nextInt();
        if (x==0){
          hmMenu.hmMenu();
        }
        else dDao.deleteTrainerById(x);
        hmMenu.hmMenu();
    }
    
   public void deleteApc() throws NoSuchAlgorithmException, InvalidKeySpecException{
        int x;
        HmMenu hmMenu = new HmMenu();
        ViewDao vDao = new ViewDao();
        DeleteDao dDao = new DeleteDao();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of all assignments per course.\n");
        vDao.getApc();
        System.out.println("\nPlease type the ID of the entry you wish to delete\n"
                + "Or type 0 to go back to headmaster-menu");
        x = input.nextInt();
        if (x==0){
          hmMenu.hmMenu();
        }
        else dDao.deleteApcById(x);
        hmMenu.hmMenu();
    }
   
   public void deleteSpc() throws NoSuchAlgorithmException, InvalidKeySpecException{
        int x;
        HmMenu hmMenu = new HmMenu();
        ViewDao vDao = new ViewDao();
        DeleteDao dDao = new DeleteDao();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of all students per course.\n");
        vDao.getSpc();
        System.out.println("\nPlease type the ID of the entry you wish to delete\n"
                + "Or type 0 to go back to headmaster-menu");
        x = input.nextInt();
        if (x==0){
          hmMenu.hmMenu();
        }
        else dDao.deleteSpcById(x);
        hmMenu.hmMenu();
    }
   
   public void deleteTpc() throws NoSuchAlgorithmException, InvalidKeySpecException{
        int x;
        HmMenu hmMenu = new HmMenu();
        ViewDao vDao = new ViewDao();
        DeleteDao dDao = new DeleteDao();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of all trainers per course.\n");
        vDao.getTpc();
        System.out.println("\nPlease type the ID of the entry you wish to delete\n"
                + "Or type 0 to go back to headmaster-menu");
        x = input.nextInt();
        if (x==0){
          hmMenu.hmMenu();
        }
        else dDao.deleteTpcById(x);
        hmMenu.hmMenu();
    } 
}
