package trMenuOptions;

import menus.TrMenu;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;
import trDao.ViewSpcDao;

/**
 *
 * @author Lena
 */
public class ViewSpc {
    
    public void viewSpc(int trainersID) throws NoSuchAlgorithmException, InvalidKeySpecException {
        int x;
        TrMenu trMenu = new TrMenu();

        ViewSpcDao vsDao = new ViewSpcDao();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of all the students in the courses you're teaching.\n");
        vsDao.viewSpcDao(trainersID);
        
        do {
            System.out.println("\nPlease type 0 to go back to students-menu");
            x = input.nextInt();
            if (x == 0) {
                trMenu.getTrMenu(trainersID);
            }
        } while (x != 0);

    }
    
}
