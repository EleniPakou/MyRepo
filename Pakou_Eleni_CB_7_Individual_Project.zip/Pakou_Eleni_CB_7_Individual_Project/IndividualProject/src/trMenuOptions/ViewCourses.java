package trMenuOptions;

import menus.TrMenu;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;
import trDao.ViewCoursesDao;

/**
 *
 * @author Lena
 */
public class ViewCourses {
    
    public void viewCourses(int trainersID) throws NoSuchAlgorithmException, InvalidKeySpecException {
        int x;
        TrMenu trMenu = new TrMenu();

        ViewCoursesDao vcDao = new ViewCoursesDao();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of all the courses you're teaching.\n");
        vcDao.viewCoursesDao(trainersID);
        
        do {
            System.out.println("\nPlease type 0 to go back to trainers-menu");
            x = input.nextInt();
            if (x == 0) {
                trMenu.getTrMenu(trainersID);
            }
        } while (x != 0);

    }
    
}
