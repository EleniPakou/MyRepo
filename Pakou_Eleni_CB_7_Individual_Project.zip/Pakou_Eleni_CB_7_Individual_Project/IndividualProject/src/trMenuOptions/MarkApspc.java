package trMenuOptions;

import menus.TrMenu;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;
import trDao.MarkApspcDao;

/**
 *
 * @author Lena
 */
public class MarkApspc {
    
    public void markApspc(int trainersID) throws NoSuchAlgorithmException, InvalidKeySpecException{
        int x;
        TrMenu trMenu = new TrMenu();
        
        MarkApspcDao maDao = new MarkApspcDao();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of the assignments per student per course you teach in\n");
        maDao.viewApcpsDao(trainersID);
        System.out.println("\nPlease type the ID of the assignment you wish to mark\n"
                + "Or type 0 to go back to trainers-menu");
        x = input.nextInt();
        if (x==0){
          trMenu.getTrMenu(trainersID);
        }
        else maDao.markApspcDao(x, trainersID);
        
    }
    
}
