package trMenuOptions;

import menus.TrMenu;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;
import trDao.ViewApspcDao;

/**
 *
 * @author Lena
 */
public class ViewApspc {
    
    public void viewApspc(int trainersID) throws NoSuchAlgorithmException, InvalidKeySpecException {
        int x;
        TrMenu trMenu = new TrMenu();

        ViewApspcDao vaDao = new ViewApspcDao();
        Scanner input = new Scanner(System.in);
        System.out.println("\nBelow is a list of all the assignments of the students in the courses you're teaching.\n");
        vaDao.viewApcpsDao(trainersID);
        
        do {
            System.out.println("\nPlease type 0 to go back to trainers-menu");
            x = input.nextInt();
            if (x == 0) {
                trMenu.getTrMenu(trainersID);
            }
        } while (x != 0);

    }
    
}
