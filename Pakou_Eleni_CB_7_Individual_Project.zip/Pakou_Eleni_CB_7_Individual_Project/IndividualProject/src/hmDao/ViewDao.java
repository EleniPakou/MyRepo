package hmDao;

import entities.Assignment;
import entities.Course;
import entities.Student;
import entities.Trainer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lena
 */
public class ViewDao {
    
    private final String URL = "jdbc:mysql://localhost:3306/private_school?serverTimezone=UTC"; 
    private final String USERNAME = "root";
    private final String PASS = "001908xxxx";
    private Connection conn;
    
    private Connection getConnection(){
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
//            System.out.println("Connection successfully established.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }
    
    private void closeConnection(){
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(ViewDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public List<Course> getListOfCourses(){
        List<Course> list = new ArrayList();
        String query = "select * from courses";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                Course c = new Course(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
                list.add(c);
                System.out.println(c);
            }
            rs.close();
            st.close();
            //conn.close();
            closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(ViewDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    
    public List<Assignment> getListOfAssignments(){
        List<Assignment> list = new ArrayList();
        String query = "select assignmentsID, Title, Description, Submission, OralMark, TotalMark from assignments";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                Assignment a = new Assignment(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getInt(6));
                list.add(a);
                System.out.println(a);
            }
            rs.close();
            st.close();
            //conn.close();
            closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(ViewDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    
    public List<Student> getListOfStudents(){
        List<Student> list = new ArrayList();
        String query = "select * from students";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                Student s = new Student(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getDouble(5));
                list.add(s);
                System.out.println(s);
            }
            rs.close();
            st.close();
            //conn.close();
            closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(ViewDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    
    public List<Trainer> getListOfTrainers(){
        List<Trainer> list = new ArrayList();
        String query = "select * from trainers";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                Trainer t = new Trainer(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
                list.add(t);
                System.out.println(t);
            }
            rs.close();
            st.close();
            //conn.close();
            closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(ViewDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    
    public void getApc() {
        String query = "select a.assignmentsID, c.Title, c.Stream, c.Type, a.Title "
                + "from courses c inner join assignments a on c.coursesID = a.cID";
        Connection con = getConnection();
        PreparedStatement pst = null;
        ResultSet rs = null;
        try {
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("a.assignmentsID");
                String title = rs.getString("c.Title");
                String stream = rs.getString("c.Stream");
                String type = rs.getString("c.Type");
                String atitle = rs.getString("a.Title");
                System.out.println(id+" "+title+" "+stream+" "+type+" "+atitle);                
            }

        } catch (SQLException x) {
            Logger.getLogger(ViewDao.class.getName()).log(Level.SEVERE, null, x);
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException x) {
                Logger.getLogger(ViewDao.class.getName()).log(Level.SEVERE, null, x);
            }
        }

    }
    public void getSpc() {
        String query = "select spc.ID, c.Title, c.Stream, c.Type, s.FirstName, s.LastName "
                + "from students_per_course spc inner join courses c on spc.cID = c.coursesID "
                + "inner join students s on spc.sID = s.studentsID";
        Connection con = getConnection();
        PreparedStatement pst = null;
        ResultSet rs = null;
        try {
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("spc.ID");
                String title = rs.getString("c.Title");
                String stream = rs.getString("c.Stream");
                String type = rs.getString("c.Type");
                String firstName = rs.getString("s.FirstName");
                String lastName = rs.getString("s.LastName");
                System.out.println(id+" "+title+" "+stream+" "+type+" "+firstName+" "+lastName);                
            }

        } catch (SQLException x) {
            Logger.getLogger(ViewDao.class.getName()).log(Level.SEVERE, null, x);
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException x) {
                Logger.getLogger(ViewDao.class.getName()).log(Level.SEVERE, null, x);
            }
        }

    }
    
    public void getTpc() {
        String query = "select tpc.ID, c.Title, c.Stream, c.Type, t.FirstName, t.LastName "
                + "from trainers_per_course tpc inner join courses c on tpc.cID = c.coursesID "
                + "inner join trainers t on tpc.tID = t.trainersID";
        Connection con = getConnection();
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("tpc.ID");
                String title = rs.getString("c.Title");
                String stream = rs.getString("c.Stream");
                String type = rs.getString("c.Type");
                String firstName = rs.getString("t.FirstName");
                String lastName = rs.getString("t.LastName");
                System.out.println(id+" "+title+" "+stream+" "+type+" "+firstName+" "+lastName);
            }

        } catch (SQLException x) {
            Logger.getLogger(ViewDao.class.getName()).log(Level.SEVERE, null, x);
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException x) {
                Logger.getLogger(ViewDao.class.getName()).log(Level.SEVERE, null, x);
            }
        }

    }
}
