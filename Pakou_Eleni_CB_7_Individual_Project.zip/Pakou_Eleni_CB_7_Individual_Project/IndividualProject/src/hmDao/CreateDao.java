package hmDao;

import entities.Assignment;
import entities.Course;
import entities.Student;
import entities.Trainer;
import entitiesPerAndLogin.AssignmentsPerCourse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lena
 */
public class CreateDao {
    
    private final String URL = "jdbc:mysql://localhost:3306/private_school?serverTimezone=UTC"; 
    private final String USERNAME = "root";
    private final String PASS = "001908xxxx";
    private Connection conn;
    
    private Connection getConnection(){
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
//            System.out.println("Connection successfully established.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }
    
    private void closeConnection(){
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(CreateDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void insertCourse(){
        String query = "insert into courses (title, stream, type, startDate, endDate) values (?,?,?,?,?)";
        
        Scanner input = new Scanner(System.in);
        Course c = new Course();
        
        System.out.print("\nPlease type the title of the course: ");
        c.setTitle(input.next());

        System.out.print("Please type the stream of the course: ");
        c.setStream(input.next());

        System.out.print("Please type the type of the course: ");
        c.setType(input.next());

        System.out.println("Please type the start date of the course: ");
        c.setStartDate(input.next());

        System.out.println("Please type the end date of the course: ");
        c.setEndDate(input.next());

        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, c.getTitle());
            pst.setString(2, c.getStream());
            pst.setString(3, c.getType());
            pst.setString(4, c.getStartDate());
            pst.setString(5, c.getEndDate());
            int number = pst.executeUpdate();
            if(number>0){
                System.out.println("\nSuccessfully added!!!");
            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(CreateDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void insertAssignment(){
        String query = "insert into assignments (title, description, submission, oralMark, totalMark) values (?,?,?,?,?)";
        
        Scanner input = new Scanner(System.in);
        Assignment a = new Assignment();
        
        System.out.print("\nPlease type the title of the assignment: ");
        a.setTitle(input.next());

        System.out.print("Please type the description of the assignment: ");
        a.setDescription(input.next());

        System.out.print("Please type the submission date and time of the assignment: ");
        a.setSubmission(input.next());

        System.out.println("Please type the oral mark of the assignment: ");
        a.setOralMark(input.nextInt());

        System.out.println("Please type the total mark of the assignment: ");
        a.setTotalMark(input.nextInt());
        
        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, a.getTitle());
            pst.setString(2, a.getDescription());
            pst.setString(3, a.getSubmission());
            pst.setInt(4, a.getOralMark());
            pst.setInt(5, a.getTotalMark());
            int number = pst.executeUpdate();
            if(number>0){
                System.out.println("\nSuccessfully added!!!");
            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException x) {
            Logger.getLogger(CreateDao.class.getName()).log(Level.SEVERE, null, x);
        }
    }
    
    public void insertStudent(){
        String query = "insert into students (firstName, lastName, dateOfBirth, tuitionFees) values (?,?,?,?)";
        
        Scanner input = new Scanner(System.in);
        Student s = new Student();
        
        System.out.print("\nPlease type the first name of student: ");
        s.setFirstName(input.next());

        System.out.print("Please type the last name of student: ");
        s.setLastName(input.next());

        System.out.print("Please type the date of birth of student: ");
        s.setDateOfBirth(input.next());

        System.out.println("Please type the tuition fees of student: ");
        s.setTuitionFees(input.nextDouble());
        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, s.getFirstName());
            pst.setString(2, s.getLastName());
            pst.setString(3, s.getDateOfBirth());
            pst.setDouble(4, s.getTuitionFees());
            int number = pst.executeUpdate();
            if(number>0){
                System.out.println("\nSuccessfully added!!!");
            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(CreateDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void insertTrainer(){
        String query = "insert into trainers (firstName, lastName, subject) values (?,?,?)";
        
        Scanner input = new Scanner(System.in);
        Trainer t = new Trainer();
        
        System.out.print("\nPlease type the first name of trainer: ");
        t.setFirstName(input.next());

        System.out.print("Please type the last name of trainer: ");
        t.setLastName(input.next());

        System.out.print("Please type the subject of trainer: ");
        t.setSubject(input.next());

        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, t.getFirstName());
            pst.setString(2, t.getLastName());
            pst.setString(3, t.getSubject());
            int number = pst.executeUpdate();
            if(number>0){
                System.out.println("\nSuccessfully added!!!");
            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(CreateDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void insertApc(int cID){
        String query = "insert into assignments (title, description, submission, oralMark, totalMark, cID) values (?,?,?,?,?,?)";

        Scanner input = new Scanner(System.in);
        AssignmentsPerCourse apc = new AssignmentsPerCourse();
        
        System.out.print("\nPlease type the title of the assignment: ");
        apc.setTitle(input.next());

        System.out.print("Please type the description of the assignment: ");
        apc.setDescription(input.next());

        System.out.print("Please type the submission date and time of the assignment: ");
        apc.setSubmission(input.next());

        System.out.println("Please type the oral mark of the assignment: ");
        apc.setOralMark(input.nextInt());

        System.out.println("Please type the total mark of the assignment: ");
        apc.setTotalMark(input.nextInt());
        
        apc.setcID(cID);
        
        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, apc.getTitle());
            pst.setString(2, apc.getDescription());
            pst.setString(3, apc.getSubmission());
            pst.setInt(4, apc.getOralMark());
            pst.setInt(5, apc.getTotalMark());
            pst.setInt(6, cID);
            int number = pst.executeUpdate();
            if(number>0){
                System.out.println("\nSuccessfully added!!!");

            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException x) {
            Logger.getLogger(CreateDao.class.getName()).log(Level.SEVERE, null, x);
        }
    }
    
    public void insertSpc(int cID, int sID){
        String query = "insert into students_per_course (cID, sID) values (?,?)";       
        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);

            pst.setInt(1, cID);
            pst.setInt(2, sID);
            
            int number = pst.executeUpdate();
            if(number>0){
                System.out.println("\nSuccessfully added!!!");

            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(CreateDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    public void insertTpc(int cID, int tID){
        String query = "insert into trainers_per_course (cID, tID) values (?,?)";       
        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);

            pst.setInt(1, cID);
            pst.setInt(2, tID);
            
            int number = pst.executeUpdate();
            if(number>0){
                System.out.println("\nSuccessfully added!!!");

            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(CreateDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
}
