package hmDao;

import entities.Assignment;
import entities.Course;
import entities.Student;
import entities.Trainer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lena
 */
public class UpdateDao {
    
    private final String URL = "jdbc:mysql://localhost:3306/private_school?serverTimezone=UTC"; 
    private final String USERNAME = "root";
    private final String PASS = "001908xxxx";
    private Connection conn;
    
    private Connection getConnection(){
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
//            System.out.println("Connection successfully established.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }
    
    private void closeConnection(){
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(UpdateDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void updateCourseById(){
        String query = "update courses set title = ?, stream = ?, type = ?, startDate = ?, endDate = ? where coursesID = ?";
        Connection con = getConnection();
        PreparedStatement pst = null;
        
        Scanner input = new Scanner(System.in);
        Course c = new Course();
        
        System.out.println("\nPlease type the ID of the course you want to update: ");
        c.setCoursesID(input.nextInt());
        
        System.out.print("\nPlease update the title of the course: ");
        c.setTitle(input.next());

        System.out.print("Please update the stream of the course: ");
        c.setStream(input.next());

        System.out.print("Please update the type of the course: ");
        c.setType(input.next());

        System.out.println("Please update the start date of the course: ");
        c.setStartDate(input.next());

        System.out.println("Please update the end date of the course: ");
        c.setEndDate(input.next());
        
        try {
            pst = con.prepareStatement(query);
            pst.setString(1, c.getTitle());
            pst.setString(2, c.getStream());
            pst.setString(3, c.getType());
            pst.setString(4, c.getStartDate());
            pst.setString(5, c.getEndDate());
            pst.setInt(6, c.getCoursesID());
            int result = pst.executeUpdate();
            if(result>0){
                System.out.println("\nSuccessfully updated!!!");
            }else{
                System.out.println("course not updated");
            }
        } catch (SQLException ex) {
            Logger.getLogger(UpdateDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                Logger.getLogger(UpdateDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void updateAssignmentById(){
        String query = "update assignments set title = ?, description = ?, submission = ?, oralMark = ?, totalMark = ? "
                + "where assignmentsID = ?";
        Connection con = getConnection();
        PreparedStatement pst = null;
        
        Scanner input = new Scanner(System.in);
        Assignment a = new Assignment();
        
        System.out.println("\nPlease type the ID of the assignment you want to update: ");
        a.setAssignmentsID(input.nextInt());
        
        System.out.print("\nPlease update the title of the assignment: ");
        a.setTitle(input.next());

        System.out.print("Please update the description of the assignment: ");
        a.setDescription(input.next());

        System.out.print("Please update the submission date and time of the assignment: ");
        a.setSubmission(input.next());

        System.out.println("Please update the oral mark of the assignment: ");
        a.setOralMark(input.nextInt());

        System.out.println("Please update the total mark of the assignment: ");
        a.setTotalMark(input.nextInt());
        
        try {
            pst = con.prepareStatement(query);
            pst.setString(1, a.getTitle());
            pst.setString(2, a.getDescription());
            pst.setString(3, a.getSubmission());
            pst.setInt(4, a.getOralMark());
            pst.setInt(5, a.getTotalMark());
            pst.setInt(6, a.getAssignmentsID());
            int result = pst.executeUpdate();
            if(result>0){
                System.out.println("\nSuccessfully updated!!!");

            }else{
                System.out.println("assignment not updated");
            }
        } catch (SQLException ex) {
            Logger.getLogger(UpdateDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                Logger.getLogger(UpdateDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void updateStudentById(){
        String query = "update students set firstName = ?, lastName = ?, dateOfBirth = ?, tuitionFees = ? where studentsID = ?";
        Connection con = getConnection();
        PreparedStatement pst = null;
        
        Scanner input = new Scanner(System.in);
        Student s = new Student();
        
        System.out.println("\nPlease type the ID of the student you want to update: ");
        s.setStudentsID(input.nextInt());
        
        System.out.print("\nPlease update the the first name of the student: ");
        s.setFirstName(input.next());

        System.out.print("Please update the the last name of the student: ");
        s.setLastName(input.next());

        System.out.print("Please update the date of birth of the student: ");
        s.setDateOfBirth(input.next());

        System.out.println("Please update the tuition fees of the student: ");
        s.setTuitionFees(input.nextInt());

        try {
            pst = con.prepareStatement(query);
            pst.setString(1, s.getFirstName());
            pst.setString(2, s.getLastName());
            pst.setString(3, s.getDateOfBirth());
            pst.setDouble(4, s.getTuitionFees());
            pst.setInt(5, s.getStudentsID());
            int result = pst.executeUpdate();
            if(result>0){
                System.out.println("\nSuccessfully updated!!!");

            }else{
                System.out.println("student not updated");
            }
        } catch (SQLException ex) {
            Logger.getLogger(UpdateDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                Logger.getLogger(UpdateDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void updateTrainerById(){
        String query = "update trainers set firstName = ?, lastName = ?, subject = ? where trainersID = ?";
        Connection con = getConnection();
        PreparedStatement pst = null;
        
        Scanner input = new Scanner(System.in);
        Trainer t = new Trainer();
        
        System.out.println("\nPlease type the ID of the trainer you want to update: ");
        t.setTrainersID(input.nextInt());
        
        System.out.print("\nPlease update the the first name of the trainer: ");
        t.setFirstName(input.next());

        System.out.print("Please update the the last name of the trainer: ");
        t.setLastName(input.next());

        System.out.print("Please update the subject of the trainer: ");
        t.setSubject(input.next());

        try {
            pst = con.prepareStatement(query);
            pst.setString(1, t.getFirstName());
            pst.setString(2, t.getLastName());
            pst.setString(3, t.getSubject());
            pst.setInt(4, t.getTrainersID());
            int result = pst.executeUpdate();
            if(result>0){
                System.out.println("\nSuccessfully updated!!!");

            }else{
                System.out.println("trainer not updated");
            }
        } catch (SQLException ex) {
            Logger.getLogger(UpdateDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                Logger.getLogger(UpdateDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void updateApcById(int assignmentsID, int cID){
        String query = "update assignments set cID =? where assignmentsID = ?";
        Connection con = getConnection();
        PreparedStatement pst = null;
        
        try {
            pst = con.prepareStatement(query);
            pst.setInt(1, cID);
            pst.setInt(2, assignmentsID);            
            int result = pst.executeUpdate();
            if(result>0){
                System.out.println("\nSuccessfully updated!!!");

            }else{
                System.out.println("assignment not updated");
            }
        } catch (SQLException ex) {
            Logger.getLogger(UpdateDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                Logger.getLogger(UpdateDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void updateSpc(int ID, int sID){
        String query = "update students_per_course set cID=(select cID from students_per_course where ID = ?), sID=? where ID=?";
       
        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);

            pst.setInt(1, ID);
            pst.setInt(2, sID);
            pst.setInt(3, ID);
            
            int number = pst.executeUpdate();
            if(number>0){
                System.out.println("\nSuccessfully updated!!!");

            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(UpdateDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    public void updateTpc(int ID, int tID){
        String query = "update trainers_per_course set cID=(select cID from trainers_per_course where ID = ?), tID=? where ID=?";
       
        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);

            pst.setInt(1, ID);
            pst.setInt(2, tID);
            pst.setInt(3, ID);
            
            int number = pst.executeUpdate();
            if(number>0){
                System.out.println("\nSuccessfully updated!!!");
            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(UpdateDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
}
