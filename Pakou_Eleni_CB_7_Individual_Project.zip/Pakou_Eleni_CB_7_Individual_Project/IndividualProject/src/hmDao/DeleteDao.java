package hmDao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lena
 */
public class DeleteDao {
    
    private final String URL = "jdbc:mysql://localhost:3306/private_school?serverTimezone=UTC"; 
    private final String USERNAME = "root";
    private final String PASS = "001908xxxx";
    private Connection conn;
    
    private Connection getConnection(){
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
//            System.out.println("Connection successfully established.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }
    
    private void closeConnection(){
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(DeleteDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void deleteCourseById(int coursesID){
        String query = "delete from courses where coursesID = ?";
        Connection con = getConnection();
        PreparedStatement pst = null;
        
        try{
            pst = con.prepareStatement(query);
            pst.setInt(1,coursesID);
            int result = pst.executeUpdate();
//            System.out.println("result value is " + result);
            if(result>0){
                System.out.println("\nSuccessfully deleted!!!");
            }else{
                System.out.println("The course with id "+coursesID+" was not found");
            }
        }catch (SQLException ex) {
            Logger.getLogger(DeleteDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                Logger.getLogger(DeleteDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }    
    }
    
    public void deleteAssignmentById(int assignmentsID){
        String query = "delete from assignments where assignmentsID = ?";
        Connection con = getConnection();
        PreparedStatement pst = null;
        
        try{
            pst = con.prepareStatement(query);
            pst.setInt(1,assignmentsID);
            int result = pst.executeUpdate();
//            System.out.println("result value is " + result);
            if(result>0){
                System.out.println("\nSuccessfully deleted!!!");
            }else{
                System.out.println("The assignment with id "+assignmentsID+" was not found");
            }
        }catch (SQLException ex) {
            Logger.getLogger(DeleteDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                Logger.getLogger(DeleteDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }    
    }
    
    public void deleteStudentById(int studentsID){
        String query = "delete from students where studentsID = ?";
        Connection con = getConnection();
        PreparedStatement pst = null;
        
        try{
            pst = con.prepareStatement(query);
            pst.setInt(1,studentsID);
            int result = pst.executeUpdate();
//            System.out.println("result value is " + result);
            if(result>0){
                System.out.println("\nSuccessfully deleted!!!");
            }else{
                System.out.println("The student with id "+studentsID+" was not found");
            }
        }catch (SQLException ex) {
            Logger.getLogger(DeleteDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                Logger.getLogger(DeleteDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }    
    }
    
    public void deleteTrainerById(int trainersID){
        String query = "delete from trainers where trainersID = ?";
        Connection con = getConnection();
        PreparedStatement pst = null;
        
        try{
            pst = con.prepareStatement(query);
            pst.setInt(1,trainersID);
            int result = pst.executeUpdate();
//            System.out.println("result value is " + result);
            if(result>0){
                System.out.println("\nSuccessfully deleted!!!");
            }else{
                System.out.println("The trainer with id "+trainersID+" was not found");
            }
        }catch (SQLException ex) {
            Logger.getLogger(DeleteDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                Logger.getLogger(DeleteDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }    
    }
    
    public void deleteApcById(int assignmentsID){
        String query = "delete from assignments where assignmentsID = ?";
        Connection con = getConnection();
        PreparedStatement pst = null;
        
        try{
            pst = con.prepareStatement(query);
            pst.setInt(1, assignmentsID);
            int result = pst.executeUpdate();
//            System.out.println("result value is " + result);
            if(result>0){
                System.out.println("\nSuccessfully deleted!!!");
            }else{
                System.out.println("The assignment_per_course with id "+assignmentsID+" was not found");
            }
        }catch (SQLException ex) {
            Logger.getLogger(DeleteDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                Logger.getLogger(DeleteDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }    
    }
    
    public void deleteSpcById(int ID){
        String query = "delete from students_per_course where ID = ?";
        Connection con = getConnection();
        PreparedStatement pst = null;
        
        try{
            pst = con.prepareStatement(query);
            pst.setInt(1, ID);
            int result = pst.executeUpdate();
//            System.out.println("result value is " + result);
            if(result>0){
                System.out.println("\nSuccessfully deleted!!!");
            }else{
                System.out.println("The student_per_course with id "+ID+" was not found");
            }
        }catch (SQLException ex) {
            Logger.getLogger(DeleteDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                Logger.getLogger(DeleteDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }    
    }
    
    public void deleteTpcById(int ID){
        String query = "delete from trainers_per_course where ID = ?";
        Connection con = getConnection();
        PreparedStatement pst = null;
        
        try{
            pst = con.prepareStatement(query);
            pst.setInt(1,ID);
            int result = pst.executeUpdate();
//            System.out.println("result value is " + result);
            if(result>0){
                System.out.println("\nSuccessfully deleted!!!");
            }else{
                System.out.println("The trainer_per_course with id "+ID+" was not found");
            }
        }catch (SQLException ex) {
            Logger.getLogger(DeleteDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                Logger.getLogger(DeleteDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }    
    }
    
}
