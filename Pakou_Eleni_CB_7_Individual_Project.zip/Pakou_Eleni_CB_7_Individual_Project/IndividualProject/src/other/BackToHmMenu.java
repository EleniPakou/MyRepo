package other;

import menus.HmMenu;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;

/**
 *
 * @author Lena
 */
public class BackToHmMenu {
    
    public void backToHmMenu() throws NoSuchAlgorithmException, InvalidKeySpecException{
        int x;
        HmMenu hmMenu = new HmMenu();
        Scanner input = new Scanner(System.in);
        do {
            System.out.println("\nPlease type 0 to go back to headmaster-menu");
            x = input.nextInt();
            if (x == 0) {
                hmMenu.hmMenu();
            }
        } while (x != 0);
    }
    
}
