package other;

/**
 *
 * @author Lena
 */
public class Goodbye {
    
    public void goodbye(){
        System.out.println("\nThank you for using our application!!!\nCU SOON!!!");
    }
}
