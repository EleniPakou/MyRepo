package other;

import giveCredentials.GiveCredentialsHm;
import giveCredentials.GiveCredentialsSt;
import giveCredentials.GiveCredentialsTr;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;

/**
 *
 * @author Lena
 */
public class LoginAs {

    public void loginAs() throws NoSuchAlgorithmException, InvalidKeySpecException {
        int role;
        Scanner input = new Scanner(System.in);
        GiveCredentialsSt giveCredSt = new GiveCredentialsSt();
        GiveCredentialsTr giveCredTr = new GiveCredentialsTr();
        GiveCredentialsHm giveCredHm = new GiveCredentialsHm();
        Goodbye goodbye = new Goodbye();
        do {
            System.out.println("\nLogin as: (Please type the right number)\n1 Student\n2 Trainer\n3 Headmaster\n4 Exit\n");
            while (!input.hasNextInt()) {
                System.out.println("\nPlease type a number! Login as:\n"
                        + "1 Student\n2 Trainer\n3 Headmaster\n4 Exit\n");
                input.next();
            }
            role = input.nextInt();

            switch (role) {
                case 1:
                    giveCredSt.giveCredentialsSt();
                    break;
                case 2:
                    giveCredTr.giveCredentialsTr();
                    break;
                case 3:
                    giveCredHm.giveCredentialsHm();
                    break;
                case 4:
                    goodbye.goodbye();
                    break;
            }

        } while (role < 1 || role > 4);
    }
}
