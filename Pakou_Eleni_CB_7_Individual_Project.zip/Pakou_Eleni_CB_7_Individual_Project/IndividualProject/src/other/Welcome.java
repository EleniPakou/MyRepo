package other;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

/**
 *
 * @author Lena
 */
public class Welcome {
    
    public void welcome() throws NoSuchAlgorithmException, InvalidKeySpecException{
        
        System.out.println("Welcome to MyPrivateSchool Application!!!");
        LoginAs loginAs = new LoginAs();
        loginAs.loginAs();
    }
    
}
