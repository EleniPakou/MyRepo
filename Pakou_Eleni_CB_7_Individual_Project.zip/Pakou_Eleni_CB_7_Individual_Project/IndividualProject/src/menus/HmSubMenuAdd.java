package menus;

import other.Goodbye;
import other.LoginAs;
import hmMenuOptions.Create;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;

/**
 *
 * @author Lena
 */
public class HmSubMenuAdd {

    public void hmSubMenuAdd() throws NoSuchAlgorithmException, InvalidKeySpecException {
        int selection;
        Create create = new Create();
        LoginAs loginAs = new LoginAs();
        Goodbye goodbye = new Goodbye();
        Scanner input = new Scanner(System.in);
        do {
            System.out.println("\nYou chose to add data!\n"
                    + "What would you like to do next? (Please type the right number)\n");
            System.out.println("1 Add a course\n2 Add an assignment\n3 Add a student\n4 Add a trainer\n"
                    + "5 Add an assignment per course\n6 Add a student per course\n"
                    + "7 Add a trainer per course\n8 Logout\n9 Exit");
            while (!input.hasNextInt()) {
                System.out.println("\nPlease type a number!");
                input.next();
            }
            selection = input.nextInt();

            switch (selection) {
                case 1:
                    create.createCourse();
                    break;
                case 2:
                    create.createAssignment();
                    break;
                case 3:
                    create.createStudent();
                    break;
                case 4:
                    create.createTrainer();
                    break;
                case 5:
                    create.createApc();
                    break;
                case 6:
                    create.createSpc();
                    break;
                case 7:
                    create.createTpc();
                    break;
                case 8:
                    loginAs.loginAs();
                    break;
                case 9:
                    goodbye.goodbye();
                    break;

            }
        } while (selection < 1 || selection > 9);
    }
}
