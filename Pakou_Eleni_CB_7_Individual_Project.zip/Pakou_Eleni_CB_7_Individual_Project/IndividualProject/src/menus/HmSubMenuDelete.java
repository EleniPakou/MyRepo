package menus;

import other.Goodbye;
import other.LoginAs;
import hmMenuOptions.Delete;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;

/**
 *
 * @author Lena
 */
public class HmSubMenuDelete {

    public void hmSubMenuDelete() throws NoSuchAlgorithmException, InvalidKeySpecException {
        int selection;
        Delete delete = new Delete();
        LoginAs loginAs = new LoginAs();
        Goodbye goodbye = new Goodbye();
        Scanner input = new Scanner(System.in);
        do {
            System.out.println("\nYou chose to delete data!\n"
                    + "What would you like to do next? (Please type the right number)\n");
            System.out.println("1 Delete a course\n2 Delete an assignment\n3 Delete a student\n4 Delete a trainer\n"
                    + "5 Delete an assignment per course\n6 Delete a student per course\n"
                    + "7 Delete a trainer per course\n8 Logout\n9 Exit");
            while (!input.hasNextInt()) {
                System.out.println("\nPlease type a number!");
                input.next();
            }
            selection = input.nextInt();

            switch (selection) {
                case 1:
                    delete.deleteCourse();
                    break;
                case 2:
                    delete.deleteAssignment();
                    break;
                case 3:
                    delete.deleteStudent();
                    break;
                case 4:
                    delete.deleteTrainer();
                    break;
                case 5:
                    delete.deleteApc();
                    break;
                case 6:
                    delete.deleteSpc();
                    break;
                case 7:
                    delete.deleteTpc();
                    break;
                case 8:
                    loginAs.loginAs();
                    break;
                case 9:
                    goodbye.goodbye();
                    break;

            }
        } while (selection < 1 || selection > 9);
    }
}
