package menus;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import other.Goodbye;
import other.LoginAs;
import java.util.Scanner;

/**
 *
 * @author Lena
 */
public class HmMenu {

    public void hmMenu() throws NoSuchAlgorithmException, InvalidKeySpecException {
        int selection;
        HmSubMenuView hmSubMenuView = new HmSubMenuView();
        HmSubMenuAdd hmSubMenuAdd = new HmSubMenuAdd();
        HmSubMenuUpdate hmSubMenuUpdate = new HmSubMenuUpdate();
        HmSubMenuDelete hmSubMenuDelete = new HmSubMenuDelete();
        LoginAs loginAs = new LoginAs();
        Goodbye goodbye = new Goodbye();
        Scanner input = new Scanner(System.in);
        do {
            System.out.println("\nWhat would you like to do next? (Please type the right number)");
            System.out.println("1 View data\n"
                    + "2 Add data\n"
                    + "3 Update data\n"
                    + "4 Delete data\n"
                    + "5 Logout\n"
                    + "6 Exit");
            while (!input.hasNextInt()) {
                System.out.println("\nPlease type a number!");
                input.next();
            }
            selection = input.nextInt();

            switch (selection) {
                case 1:
                    hmSubMenuView.hmSubMenuView();
                    break;
                case 2:
                    hmSubMenuAdd.hmSubMenuAdd();
                    break;
                case 3:
                    hmSubMenuUpdate.hmSubMenuUpdate();
                    break;
                case 4:
                    hmSubMenuDelete.hmSubMenuDelete();
                    break;
                case 5:
                    loginAs.loginAs();
                    break;
                case 6:
                    goodbye.goodbye();
                    break;

            }
        } while (selection < 1 || selection > 6);
    }

}
