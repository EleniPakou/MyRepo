package menus;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import other.Goodbye;
import other.LoginAs;
import java.util.Scanner;
import stMenuOptions.Enroll;
import stMenuOptions.SubmissionDates;
import stMenuOptions.SubmitAssignment;

/**
 *
 * @author Lena
 */
public class StMenu {

    public void getStMenu(int studentsID) throws NoSuchAlgorithmException, InvalidKeySpecException {
        int selection;
        Enroll enroll = new Enroll();
        SubmissionDates subDates = new SubmissionDates();
        SubmitAssignment subAssgnm = new SubmitAssignment();
        LoginAs loginAs = new LoginAs();
        Goodbye goodbye = new Goodbye();
        Scanner input = new Scanner(System.in);
        do {
            System.out.println("\nWhat would you like to do next? (Please type the right number)");
            System.out.println("1 See the submission dates of your assignments\n"
                    + "2 Submit your assignments\n"
                    + "3 Enroll to a course under any of its trainers\n"
                    + "4 Logout\n"
                    + "5 Exit");
            while (!input.hasNextInt()) {
                System.out.println("\nPlease type a number!");
                input.next();
            }
            selection = input.nextInt();

            switch (selection) {
                case 1:
                    subDates.submissionDates(studentsID);
                    break;
                case 2:
                    subAssgnm.submitAssignment(studentsID);
                    break;
                case 3:
                    enroll.enroll(studentsID);
                    break;
                case 4:
                    loginAs.loginAs();
                    break;
                case 5:
                    goodbye.goodbye();
                    break;

            }
        } while (selection < 1 || selection > 5);
    }
}
