package menus;

import other.Goodbye;
import other.LoginAs;
import hmMenuOptions.Update;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;

/**
 *
 * @author Lena
 */
public class HmSubMenuUpdate {

    public void hmSubMenuUpdate() throws NoSuchAlgorithmException, InvalidKeySpecException {
        int selection;
        Update update = new Update();
        LoginAs loginAs = new LoginAs();
        Goodbye goodbye = new Goodbye();
        Scanner input = new Scanner(System.in);
        do {
            System.out.println("\nYou chose to update data!\n"
                    + "What would you like to do next? (Please type the right number)\n");
            System.out.println("1 Update a course\n2 Update an assignment\n3 Update a student\n4 Update a trainer\n"
                    + "5 Update an assignment per course\n6 Update a student per course\n"
                    + "7 Update a trainer per course\n8 Logout\n9 Exit");
            while (!input.hasNextInt()) {
                System.out.println("\nPlease type a number!");
                input.next();
            }
            selection = input.nextInt();

            switch (selection) {
                case 1:
                    update.updateCourse();
                    break;
                case 2:
                    update.updateAssignment();
                    break;
                case 3:
                    update.updateStudent();
                    break;
                case 4:
                    update.updateTrainer();
                    break;
                case 5:
                    update.updateApc();
                    break;
                case 6:
                    update.updateSpc();
                    break;
                case 7:
                    update.updateTpc();
                    break;
                case 8:
                    loginAs.loginAs();
                    break;
                case 9:
                    goodbye.goodbye();
                    break;

            }
        } while (selection < 1 || selection > 9);
    }
}
