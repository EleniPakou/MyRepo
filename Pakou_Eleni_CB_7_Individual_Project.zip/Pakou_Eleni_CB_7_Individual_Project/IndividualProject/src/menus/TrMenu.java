package menus;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import other.Goodbye;
import other.LoginAs;
import java.util.Scanner;
import trMenuOptions.MarkApspc;
import trMenuOptions.ViewApspc;
import trMenuOptions.ViewCourses;
import trMenuOptions.ViewSpc;

/**
 *
 * @author Lena
 */
public class TrMenu {

    public void getTrMenu(int trainersID) throws NoSuchAlgorithmException, InvalidKeySpecException {
        int selection;

        Scanner input = new Scanner(System.in);
        ViewCourses viewCourses = new ViewCourses();
        ViewSpc viewSpc = new ViewSpc();
        ViewApspc viewApspc = new ViewApspc();
        MarkApspc markApspc = new MarkApspc();
        LoginAs loginAs = new LoginAs();
        Goodbye goodbye = new Goodbye();

        do {
            System.out.println("\nWhat would you like to do next? (Please type the right number)");
            System.out.println("1 View all the courses you are enrolled\n"
                    + "2 View all the students per course you are enrolled\n"
                    + "3 View all the assignments per student per course\n"
                    + "4 Mark all the assignments per per student course\n"
                    + "5 Logout\n"
                    + "6 Exit");
            while (!input.hasNextInt()) {
                System.out.println("\nPlease type a number!");
                input.next();
            }
            selection = input.nextInt();

            switch (selection) {
                case 1:
                    viewCourses.viewCourses(trainersID);
                    break;
                case 2:
                    viewSpc.viewSpc(trainersID);
                    break;
                case 3:
                    viewApspc.viewApspc(trainersID);
                    break;
                case 4:
                    markApspc.markApspc(trainersID);
                    break;
                case 5:
                    loginAs.loginAs();
                    break;
                case 6:
                    goodbye.goodbye();
                    break;
                default:
                    break;
            }
        } while (selection < 1 || selection > 6);
    }

}
