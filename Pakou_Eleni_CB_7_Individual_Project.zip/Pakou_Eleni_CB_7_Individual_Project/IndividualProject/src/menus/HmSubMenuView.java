package menus;

import other.Goodbye;
import other.LoginAs;
import hmMenuOptions.View;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;

/**
 *
 * @author Lena
 */
public class HmSubMenuView {

    public void hmSubMenuView() throws NoSuchAlgorithmException, InvalidKeySpecException {
        int selection;
        View view = new View();
        LoginAs loginAs = new LoginAs();
        Goodbye goodbye = new Goodbye();
        Scanner input = new Scanner(System.in);
        do {
            System.out.println("\nYou chose to view data!\n"
                    + "What would you like to do next? (Please type the right number)\n");
            System.out.println("1 View list of courses\n2 View list of assignments\n3 View list of students\n4 View list of trainers\n"
                    + "5 View list of assignments per course\n6 View list of students per course\n"
                    + "7 View list of trainers per course\n8 Logout\n9 Exit");
            while (!input.hasNextInt()) {
                System.out.println("\nPlease type a number!");
                input.next();
            }
            selection = input.nextInt();

            switch (selection) {
                case 1:
                    view.viewCourses();
                    break;
                case 2:
                    view.viewAssignments();
                    break;
                case 3:
                    view.viewStudents();
                    break;
                case 4:
                    view.viewTrainers();
                    break;
                case 5:
                    view.viewApc();
                    break;
                case 6:
                    view.viewSpc();
                    break;
                case 7:
                    view.viewTpc();
                    break;
                case 8:
                    loginAs.loginAs();
                    break;
                case 9:
                    goodbye.goodbye();
                    break;

            }
        } while (selection < 1 || selection > 9);
    }
}
