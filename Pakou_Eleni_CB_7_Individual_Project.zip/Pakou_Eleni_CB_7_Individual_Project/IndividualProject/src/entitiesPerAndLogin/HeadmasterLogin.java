package entitiesPerAndLogin;

/**
 *
 * @author Lena
 */
public class HeadmasterLogin {
    private int ID;
    private String firstName;
    private String lastName;
    private String userName;
    private String password;
    private String hash;

    public HeadmasterLogin() {
    }

    public HeadmasterLogin(int ID, String firstName, String lastName, String userName, String password, String hash) {
        this.ID = ID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.password = password;
        this.hash = hash;        
    }

    public HeadmasterLogin(String firstName, String lastName, String userName, String password, String hash) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.password = password;
        this.hash = hash;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }    

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }
    
    @Override
    public String toString() {
        return super.toString();
    }

}
