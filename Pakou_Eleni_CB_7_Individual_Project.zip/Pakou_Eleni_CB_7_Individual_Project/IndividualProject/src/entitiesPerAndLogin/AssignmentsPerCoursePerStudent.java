package entitiesPerAndLogin;

import java.time.LocalDate;

/**
 *
 * @author Lena
 */
public class AssignmentsPerCoursePerStudent {
    private int ID;
    private int sID;
    private int aID;
    private LocalDate submittedOn;
    private int oralMarkGiven;
    private int totalMarkGiven;

    public AssignmentsPerCoursePerStudent() {
    }

    public AssignmentsPerCoursePerStudent(int ID, int sID, int aID, LocalDate submittedOn, int oralMarkGiven, int totalMarkGiven) {
        this.ID = ID;
        this.sID = sID;
        this.aID = aID;
        this.submittedOn = submittedOn;
        this.oralMarkGiven = oralMarkGiven;
        this.totalMarkGiven = totalMarkGiven;
    }

    public AssignmentsPerCoursePerStudent(int sID, int aID, LocalDate submittedOn, int oralMarkGiven, int totalMarkGiven) {
        this.sID = sID;
        this.aID = aID;
        this.submittedOn = submittedOn;
        this.oralMarkGiven = oralMarkGiven;
        this.totalMarkGiven = totalMarkGiven;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getsID() {
        return sID;
    }

    public void setsID(int sID) {
        this.sID = sID;
    }

    public int getaID() {
        return aID;
    }

    public void setaID(int aID) {
        this.aID = aID;
    }

    public LocalDate getSubmittedOn() {
        return submittedOn;
    }

    public void setSubmittedOn(LocalDate submittedOn) {
        this.submittedOn = submittedOn;
    }

    public int getOralMarkGiven() {
        return oralMarkGiven;
    }

    public void setOralMarkGiven(int oralMarkGiven) {
        this.oralMarkGiven = oralMarkGiven;
    }

    public int getTotalMarkGiven() {
        return totalMarkGiven;
    }

    public void setTotalMarkGiven(int totalMarkGiven) {
        this.totalMarkGiven = totalMarkGiven;
    }

    @Override
    public String toString() {
        return super.toString(); 
    }
    
    
}
