package entitiesPerAndLogin;

/**
 *
 * @author Lena
 */
public class TrainersPerCourse {
    private int ID;
    private int cID;
    private int tID;

    public TrainersPerCourse() {
    }

    public TrainersPerCourse(int ID, int cID, int tID) {
        this.ID = ID;
        this.cID = cID;
        this.tID = tID;
    }

    public TrainersPerCourse(int cID, int tID) {
        this.cID = cID;
        this.tID = tID;
    }    

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getcID() {
        return cID;
    }

    public void setcID(int cID) {
        this.cID = cID;
    }

    public int gettID() {
        return tID;
    }

    public void settID(int tID) {
        this.tID = tID;
    }

    @Override
    public String toString() {
        return super.toString();
    }
    
}
