package entitiesPerAndLogin;

/**
 *
 * @author Lena
 */
public class StudentsPerCourse {
    private int ID;
    private int cID;
    private int sID;

    public StudentsPerCourse() {
    }

    public StudentsPerCourse(int ID, int cID, int sID) {
        this.ID = ID;
        this.cID = cID;
        this.sID = sID;
    }

    public StudentsPerCourse(int cID, int sID) {
        this.cID = cID;
        this.sID = sID;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getcID() {
        return cID;
    }

    public void setcID(int cID) {
        this.cID = cID;
    }

    public int getsID() {
        return sID;
    }

    public void setsID(int sID) {
        this.sID = sID;
    }

    @Override
    public String toString() {
        return super.toString();
    }
    
}
