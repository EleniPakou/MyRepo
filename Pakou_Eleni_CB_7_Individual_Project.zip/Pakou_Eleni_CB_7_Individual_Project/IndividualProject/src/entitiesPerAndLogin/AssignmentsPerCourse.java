package entitiesPerAndLogin;

import entities.Assignment;

/**
 *
 * @author Lena
 */
public class AssignmentsPerCourse extends Assignment {
    
    private int cID;

    public AssignmentsPerCourse() {
    }

    public AssignmentsPerCourse(int assignmentsID, String title, String description, String submission, int oralMark, int totalMark, int cID) {
        super(assignmentsID, title, description, submission, oralMark, totalMark);
        this.cID = cID;
    }

    public AssignmentsPerCourse(String title, String description, String submission, int oralMark, int totalMark, int cID) {
        super(title, description, submission, oralMark, totalMark);
        this.cID = cID;
    }

    public int getcID() {
        return cID;
    }

    public void setcID(int cID) {
        this.cID = cID;
    }

    @Override
    public String toString() {
        return super.toString();
    }
    

    
    

    
}
