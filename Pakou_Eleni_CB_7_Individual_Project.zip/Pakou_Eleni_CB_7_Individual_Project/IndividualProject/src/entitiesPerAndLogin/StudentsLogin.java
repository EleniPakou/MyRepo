package entitiesPerAndLogin;

/**
 *
 * @author Lena
 */
public class StudentsLogin {
    private int ID;
    private int sID;
    private String userName;
    private String password;
    private String hash;

    public StudentsLogin() {
    }

    public StudentsLogin(int ID, int sID, String userName, String password, String hash) {
        this.ID = ID;
        this.sID = sID;
        this.userName = userName;
        this.password = password;
        this.hash = hash;
    }

    public StudentsLogin(int sID, String userName, String password, String hash) {
        this.sID = sID;
        this.userName = userName;
        this.password = password;
        this.hash = hash;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getsID() {
        return sID;
    }

    public void setsID(int sID) {
        this.sID = sID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    @Override
    public String toString() {
        return super.toString(); 
    }
    
    
}
