package entitiesPerAndLogin;

/**
 *
 * @author Lena
 */
public class TrainersLogin {
    private int ID;
    private int tID;
    private String userName;
    private String password;
    private String hash;

    public TrainersLogin() {
    }

    public TrainersLogin(int ID, int tID, String userName, String password, String hash) {
        this.ID = ID;
        this.tID = tID;
        this.userName = userName;
        this.password = password;
        this.hash = hash;
    }

    public TrainersLogin(int tID, String userName, String password, String hash) {
        this.tID = tID;
        this.userName = userName;
        this.password = password;
        this.hash = hash;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int gettID() {
        return tID;
    }

    public void settID(int tID) {
        this.tID = tID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
