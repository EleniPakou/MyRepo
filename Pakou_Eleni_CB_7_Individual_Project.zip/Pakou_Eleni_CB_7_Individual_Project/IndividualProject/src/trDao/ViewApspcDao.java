package trDao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lena
 */
public class ViewApspcDao {
    
    private final String URL = "jdbc:mysql://localhost:3306/private_school?serverTimezone=UTC";
    private final String USERNAME = "root";
    private final String PASS = "001908xxxx";
    private Connection conn;

    private Connection getConnection() {
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
//            System.out.println("Connection successfully established.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }

    private void closeConnection() {
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(ViewApspcDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void viewApcpsDao(int trainersID) {
        String query = "select c.Title, c.Stream, c.Type, s.FirstName, s.LastName, a.Title "
                + "from assignments_per_course_per_student apcps, trainers_per_course tpc, "
                + "courses c, students s, trainers t, assignments a "
                + "where apcps.sID=s.studentsID and apcps.aID=a.assignmentsID and a.cID=c.coursesID and tpc.cID=c.coursesID "
                + "and tpc.tID=t.trainersID and trainersID=?";
        Connection con = getConnection();
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            pst = con.prepareStatement(query);
            pst.setInt(1, trainersID);
            rs = pst.executeQuery();
            while (rs.next()) {
                String title = rs.getString("c.Title");
                String stream = rs.getString("c.Stream");
                String type = rs.getString("c.Type");
                String firstName = rs.getString("s.FirstName");
                String lastName = rs.getString("s.LastName");
                String atitle = rs.getString("a.Title");
                
                System.out.println(title+" "+stream+" "+type+" "+firstName+" "+lastName+" "+atitle);
            }

        } catch (SQLException x) {
            Logger.getLogger(ViewApspcDao.class.getName()).log(Level.SEVERE, null, x);
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException x) {
                Logger.getLogger(ViewApspcDao.class.getName()).log(Level.SEVERE, null, x);
            }
        }

    }
    
}
