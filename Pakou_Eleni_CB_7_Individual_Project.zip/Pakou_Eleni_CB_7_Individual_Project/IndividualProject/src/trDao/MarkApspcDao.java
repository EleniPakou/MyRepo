package trDao;

import entitiesPerAndLogin.AssignmentsPerCoursePerStudent;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import menus.TrMenu;

/**
 *
 * @author Lena
 */
public class MarkApspcDao {

    private final String URL = "jdbc:mysql://localhost:3306/private_school?serverTimezone=UTC";
    private final String USERNAME = "root";
    private final String PASS = "001908xxxx";
    private Connection conn;

    private Connection getConnection() {
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
//            System.out.println("Connection successfully established.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }

    private void closeConnection() {
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(MarkApspcDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void viewApcpsDao(int trainersID) {
        String query = "select apcps.ID, c.Title, c.Stream, c.Type, s.FirstName, s.LastName, a.Title, "
                + "apcps.SubmittedOn, apcps.OralMarkGiven, apcps.TotalMarkGiven "
                + "from assignments_per_course_per_student apcps, trainers_per_course tpc, "
                + "courses c, students s, trainers t, assignments a "
                + "where apcps.sID=s.studentsID and apcps.aID=a.assignmentsID and a.cID=c.coursesID and tpc.cID=c.coursesID "
                + "and tpc.tID=t.trainersID and trainersID=?";
        Connection con = getConnection();
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            pst = con.prepareStatement(query);
            pst.setInt(1, trainersID);
            rs = pst.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("apcps.ID");
                String title = rs.getString("c.Title");
                String stream = rs.getString("c.Stream");
                String type = rs.getString("c.Type");
                String firstName = rs.getString("s.FirstName");
                String lastName = rs.getString("s.LastName");
                String atitle = rs.getString("a.Title");
                String submittedOn = rs.getString("apcps.SubmittedOn");
                String oralMarkGiven = rs.getString("apcps.OralMarkGiven");
                String totalMarkGiven = rs.getString("apcps.TotalMarkGiven");

                if (submittedOn == null) {
                    System.out.println("ID="+id+" | "+title+" "+stream+" "+type+" "+firstName+" "+lastName+" "+atitle+" NOT-SUBMITTED");
                } 
                else if ((submittedOn != null) && (oralMarkGiven == null)){
                    System.out.println("ID="+id+" | "+title+" "+stream+" "+type+" "+firstName+" "+lastName+" "+atitle+" SUBMITTED - NOT MARKED");
                }
                else if ((oralMarkGiven != null) && (totalMarkGiven == null)){ 
                    System.out.println("ID="+id+" | "+title+" "+stream+" "+type+" "+firstName+" "+lastName+" "+atitle+" SUBMITTED - NOT MARKED TOTAL");
                }
                else {
                    System.out.println("ID="+id+" | "+title+" "+stream+" "+type+" "+firstName+" "+lastName+" "+atitle+" SUBMITTED - MARKED");
                }

                
            }

        } catch (SQLException x) {
            Logger.getLogger(MarkApspcDao.class.getName()).log(Level.SEVERE, null, x);
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException x) {
                Logger.getLogger(MarkApspcDao.class.getName()).log(Level.SEVERE, null, x);
            }
        }

    }
    
    public void markApspcDao(int ID, int trainersID) throws NoSuchAlgorithmException, InvalidKeySpecException{
        String query = "update assignments_per_course_per_student set OralMarkGiven=?, TotalMarkGiven=? where ID=?";
        TrMenu trMenu = new TrMenu();
        
        Scanner input = new Scanner(System.in);
        AssignmentsPerCoursePerStudent apcps = new AssignmentsPerCoursePerStudent();
        
        System.out.println("\nPlease type the oral mark you want to give (max=20): ");
        apcps.setOralMarkGiven(input.nextInt());
        
        System.out.print("Please type the total mark you want to give (max=100): ");
        apcps.setTotalMarkGiven(input.nextInt());

        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);
            pst.setInt(1, apcps.getOralMarkGiven());
            pst.setInt(2, apcps.getTotalMarkGiven());
            pst.setInt(3, ID);
            
            int number = pst.executeUpdate();
            if(number>0){
                System.out.println("\nYou successfully marked the assignment!!!");
                trMenu.getTrMenu(trainersID);
            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(MarkApspcDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
