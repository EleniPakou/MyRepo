package trDao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lena
 */
public class ViewCoursesDao {
    
    private final String URL = "jdbc:mysql://localhost:3306/private_school?serverTimezone=UTC";
    private final String USERNAME = "root";
    private final String PASS = "001908xxxx";
    private Connection conn;

    private Connection getConnection() {
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
//            System.out.println("Connection successfully established.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }

    private void closeConnection() {
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(ViewCoursesDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void viewCoursesDao(int trainersID) {
        String query = "select Title, Stream, Type from trainers_per_course tpc "
                + "inner join courses c on tpc.cID=c.coursesID where tID=?";
        Connection con = getConnection();
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            pst = con.prepareStatement(query);
            pst.setInt(1, trainersID);
            rs = pst.executeQuery();
            while (rs.next()) {
                String title = rs.getString("Title");
                String stream = rs.getString("Stream");
                String type = rs.getString("Type");
                
                
                System.out.println(title+" "+stream+" "+type);
            }
        } catch (SQLException x) {
            Logger.getLogger(ViewCoursesDao.class.getName()).log(Level.SEVERE, null, x);
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException x) {
                Logger.getLogger(ViewCoursesDao.class.getName()).log(Level.SEVERE, null, x);
            }
        }

    }
}
