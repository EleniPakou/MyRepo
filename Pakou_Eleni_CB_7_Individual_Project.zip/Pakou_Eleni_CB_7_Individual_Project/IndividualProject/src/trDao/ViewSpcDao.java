package trDao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lena
 */
public class ViewSpcDao {
    
    private final String URL = "jdbc:mysql://localhost:3306/private_school?serverTimezone=UTC";
    private final String USERNAME = "root";
    private final String PASS = "001908xxxx";
    private Connection conn;

    private Connection getConnection() {
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
//            System.out.println("Connection successfully established.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }

    private void closeConnection() {
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(ViewSpcDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void viewSpcDao(int trainersID) {
        String query = "select c.Title, c.Stream, c.Type, s.FirstName, s.LastName "
                + "from students_per_course spc, students s, trainers t, courses c, trainers_per_course tpc "
                + "where spc.cID=c.coursesID and spc.sID=s.studentsID and tpc.cId=c.coursesID and tpc.tID=t.trainersID "
                + "and trainersID=?";
        Connection con = getConnection();
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            pst = con.prepareStatement(query);
            pst.setInt(1, trainersID);
            rs = pst.executeQuery();
            while (rs.next()) {
                String title = rs.getString("c.Title");
                String stream = rs.getString("c.Stream");
                String type = rs.getString("c.Type");
                String firstName = rs.getString("s.FirstName");
                String lastName = rs.getString("s.LastName");
                
                System.out.println(title+" "+stream+" "+type+" "+firstName+" "+lastName);
            }

        } catch (SQLException x) {
            Logger.getLogger(ViewSpcDao.class.getName()).log(Level.SEVERE, null, x);
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException x) {
                Logger.getLogger(ViewSpcDao.class.getName()).log(Level.SEVERE, null, x);
            }
        }

    }
    
}
