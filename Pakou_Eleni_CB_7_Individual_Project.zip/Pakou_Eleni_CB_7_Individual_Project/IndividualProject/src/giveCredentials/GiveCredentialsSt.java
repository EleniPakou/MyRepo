package giveCredentials;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import verifyCredentialsDao.VerifyStDao;
import java.util.Scanner;
import other.SecurePass;

/**
 *
 * @author Lena
 */
public class GiveCredentialsSt {
    
    public void giveCredentialsSt() throws NoSuchAlgorithmException, InvalidKeySpecException{
        Scanner input = new Scanner(System.in);
        SecurePass securePass = new SecurePass();
        VerifyStDao vstDao = new VerifyStDao();
        
        System.out.println("\nPlease give username");
        String username = input.next();
        System.out.println("Please give password");
        String password = input.next();
        
        String hashInput = securePass.securePass(password);
//        System.out.println(hashInput);
        vstDao.getCredentialsSt(username, hashInput);
    }
}    