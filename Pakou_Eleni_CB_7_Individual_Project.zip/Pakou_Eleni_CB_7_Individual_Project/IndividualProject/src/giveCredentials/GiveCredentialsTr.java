package giveCredentials;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;
import other.SecurePass;
import verifyCredentialsDao.VerifyStDao;
import verifyCredentialsDao.VerifyTrDao;

/**
 *
 * @author Lena
 */
public class GiveCredentialsTr {
    
    public void giveCredentialsTr() throws NoSuchAlgorithmException, InvalidKeySpecException{
        Scanner input = new Scanner(System.in);
        SecurePass securePass = new SecurePass();
        VerifyTrDao vtrDao = new VerifyTrDao();
        
        System.out.println("\nPlease give username");
        String username = input.next();
        System.out.println("Please give password");
        String password = input.next();
        
        String hashInput = securePass.securePass(password);
//        System.out.println(hashInput);
        vtrDao.getCredentialsTr(username, hashInput);
    }
    
}
