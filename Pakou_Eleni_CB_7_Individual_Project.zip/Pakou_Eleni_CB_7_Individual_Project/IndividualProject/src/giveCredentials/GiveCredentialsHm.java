package giveCredentials;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Scanner;
import other.SecurePass;
import verifyCredentialsDao.VerifyHmDao;

/**
 *
 * @author Lena
 */
public class GiveCredentialsHm {
    
    public void giveCredentialsHm() throws NoSuchAlgorithmException, InvalidKeySpecException{
        Scanner input = new Scanner(System.in);
        SecurePass securePass = new SecurePass();
        VerifyHmDao vhmDao = new VerifyHmDao();
        
        System.out.println("\nPlease give username");
        String username = input.next();
        System.out.println("Please give password");
        String password = input.next();
        
        String hashInput = securePass.securePass(password);
//        System.out.println(hashInput);
        vhmDao.getCredentialsHm(username, hashInput);
    }
    
}
