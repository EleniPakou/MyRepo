package entities;

/**
 *
 * @author Lena
 */
public class Trainer {
    private int trainersID;
    private String firstName;
    private String lastName;
    private String subject;

    public Trainer() {
    }

    public Trainer(int trainersID, String firstName, String lastName, String subject) {
        this.trainersID = trainersID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.subject = subject;
    }

    public Trainer(String firstName, String lastName, String subject) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.subject = subject;
    }
    
    public int getTrainersID() {
        return trainersID;
    }

    public void setTrainersID(int trainersID) {
        this.trainersID = trainersID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    @Override
    public String toString() {
        return trainersID+" "+firstName+" "+lastName+" "+subject;
    }
}
