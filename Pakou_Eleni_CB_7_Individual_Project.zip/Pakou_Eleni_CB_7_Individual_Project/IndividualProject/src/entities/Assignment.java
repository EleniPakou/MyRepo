package entities;

/**
 *
 * @author Lena
 */
public class Assignment {
    private int assignmentsID;
    private String title;
    private String description;
    private String submission;
    private int oralMark;
    private int totalMark;

    public Assignment() {
    }

    public Assignment(int assignmentsID, String title, String description, String submission, int oralMark, int totalMark) {
        this.assignmentsID = assignmentsID;
        this.title = title;
        this.description = description;
        this.submission = submission;
        this.oralMark = oralMark;
        this.totalMark = totalMark;
    }

    public Assignment(String title, String description, String submission, int oralMark, int totalMark) {
        this.title = title;
        this.description = description;
        this.submission = submission;
        this.oralMark = oralMark;
        this.totalMark = totalMark;
    }
    
    public int getAssignmentsID() {
        return assignmentsID;
    }

    public void setAssignmentsID(int assignmentsID) {
        this.assignmentsID = assignmentsID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSubmission() {
        return submission;
    }

    public void setSubmission(String submission) {
        this.submission = submission;
    }

    public int getOralMark() {
        return oralMark;
    }

    public void setOralMark(int oralMark) {
        this.oralMark = oralMark;
    }

    public int getTotalMark() {
        return totalMark;
    }

    public void setTotalMark(int totalMark) {
        this.totalMark = totalMark;
    }

    @Override
    public String toString() {
        return assignmentsID+" "+title+" "+description+" "+submission+" "+oralMark+" "+totalMark;
    }
    
}
